# Task Monitor (TM) Android App — Source Project

## MVP features
- Create tasks by Project Number; project name optional.
- Task/assignment date, description, priority, assigned person and email, due date.
- Project filter and search.
- SQLite local storage (offline-first).
- Assignment-date and due-date reminder notifications via WorkManager.
- Reminder notification has an **Email Reminder** action which opens the phone's mail app with the recipient, subject and task details prefilled.
- Mark complete and initiate a completion email.
- TM app icon and uploaded Task Monitor logo used in app header.

## Important email limitation
Android apps cannot reliably send email silently using a user's personal mail account without account/API authorization or a mail server. This MVP **initiates** emails in the user's installed mail app. To make automatic background sending (without tapping Send), a secure backend with Microsoft Graph/Gmail OAuth or SMTP service is required.

## Build APK
1. Install Android Studio on a personal computer (not necessarily office laptop).
2. Open this project folder.
3. Allow Gradle sync; install Android SDK 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Transfer the APK to your Android phone and install. Allow notifications when prompted.

Package: `com.taskmonitor.tm`
Minimum Android: 8.0 (API 26)
