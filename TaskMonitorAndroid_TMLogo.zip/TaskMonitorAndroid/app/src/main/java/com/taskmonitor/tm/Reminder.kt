package com.taskmonitor.tm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

object Reminders {
    const val CHANNEL="task_monitor_reminders"
    fun createChannel(ctx:Context){if(Build.VERSION.SDK_INT>=26){val ch=NotificationChannel(CHANNEL,"Task reminders",NotificationManager.IMPORTANCE_HIGH);ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)}}
    fun schedule(ctx:Context,t:TaskItem){
        val wm=WorkManager.getInstance(ctx)
        wm.cancelAllWorkByTag("task_${t.id}")
        val today=LocalDate.now()
        val assign=runCatching{LocalDate.parse(t.taskDate)}.getOrNull()
        val due=runCatching{LocalDate.parse(t.dueDate)}.getOrNull()
        if(assign!=null && assign.isAfter(today)) enqueue(ctx,t,"Assigned task reminder",assign.atTime(9,0),"assignment")
        else if(assign==today) enqueue(ctx,t,"Task assigned today",LocalDateTime.now().plusMinutes(1),"assignment")
        if(due!=null && due.isAfter(today)) enqueue(ctx,t,"Task due reminder",due.atTime(9,0),"due")
        else if(due==today && t.status!="Completed") enqueue(ctx,t,"Task due today",LocalDateTime.now().plusMinutes(2),"due")
    }
    private fun enqueue(ctx:Context,t:TaskItem,title:String,at:LocalDateTime,kind:String){
        val delay=maxOf(0,at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()-System.currentTimeMillis())
        val data=workDataOf("id" to t.id,"title" to title,"project" to t.projectNumber,"description" to t.description,"assignee" to t.assignee,"email" to t.email,"due" to t.dueDate,"kind" to kind)
        val req=OneTimeWorkRequestBuilder<TaskReminderWorker>().setInputData(data).setInitialDelay(delay,TimeUnit.MILLISECONDS).addTag("task_${t.id}").build()
        WorkManager.getInstance(ctx).enqueue(req)
    }
}
class TaskReminderWorker(ctx:Context,params:WorkerParameters):Worker(ctx,params){
    override fun doWork():Result {
        Reminders.createChannel(applicationContext)
        val email=inputData.getString("email")?:"";val assignee=inputData.getString("assignee")?:"";val project=inputData.getString("project")?:"";val desc=inputData.getString("description")?:"";val due=inputData.getString("due")?:"";val title=inputData.getString("title")?:"Task reminder"
        val subject=Uri.encode("Task Monitor | $project | $title")
        val body=Uri.encode("Hello $assignee,\n\nTask reminder:\nProject: $project\nTask: $desc\nDue date: $due\n\nPlease update the task status.\n\nRegards,\nTask Monitor")
        val mail=Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:$email?subject=$subject&body=$body"))
        val pending=PendingIntent.getActivity(applicationContext,inputData.getLong("id",0).toInt()+100,mail,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(applicationContext,Reminders.CHANNEL).setSmallIcon(R.drawable.tm_logo).setContentTitle(title).setContentText("$project · $desc · Due $due").setStyle(NotificationCompat.BigTextStyle().bigText("Assigned to $assignee\nProject: $project\nTask: $desc\nDue: $due\nTap Email Reminder to prepare email." )).setPriority(NotificationCompat.PRIORITY_HIGH).addAction(0,"Email Reminder",pending).setAutoCancel(true).build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(inputData.getLong("id",0).toInt(),n)
        return Result.success()
    }
}
